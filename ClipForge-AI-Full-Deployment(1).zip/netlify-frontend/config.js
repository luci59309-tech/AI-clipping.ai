// After deploying the backend, paste its public HTTPS URL here.
// Example: window.CLIPFORGE_API_URL = "https://clipforge-api.onrender.com";
window.CLIPFORGE_API_URL = "";
