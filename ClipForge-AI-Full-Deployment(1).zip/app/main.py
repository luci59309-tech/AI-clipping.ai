import os, uuid, shutil, subprocess, threading, re, json, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.getenv("DATA_DIR", str(BASE / "data")))
UPLOADS = DATA / "uploads"
OUTPUTS = DATA / "outputs"
for p in (UPLOADS, OUTPUTS):
    p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ClipForge AI", version="1.0.0")

# Set CORS_ORIGINS to your Netlify site URL(s), comma-separated.
# Example: https://your-site.netlify.app,https://www.yourdomain.com
cors_origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(BASE / "app" / "static")), name="static")
jobs = {}
job_lock = threading.Lock()

class UrlRequest(BaseModel):
    url: str
    clip_count: int = 5
    min_seconds: int = 20
    max_seconds: int = 60
    aspect: str = "9:16"

def run(cmd, timeout=None):
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout)[-2500:])
    return result.stdout.strip()

def probe_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return max(0.1, float(out))

def get_whisper_model():
    from faster_whisper import WhisperModel
    model_name = os.getenv("WHISPER_MODEL", "base")
    # CPU mode works without CUDA; set WHISPER_DEVICE=cuda only on a configured CUDA host.
    device = os.getenv("WHISPER_DEVICE", "cpu")
    compute = os.getenv("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
    return WhisperModel(model_name, device=device, compute_type=compute)

def transcribe(path):
    model = get_whisper_model()
    segments, info = model.transcribe(str(path), beam_size=3, vad_filter=True)
    rows = []
    for s in segments:
        txt = (s.text or "").strip()
        if txt:
            rows.append({"start": float(s.start), "end": float(s.end), "text": txt})
    return rows, getattr(info, "language", "unknown")

def score_segment(text, duration):
    words = re.findall(r"\b[\w']+\b", text.lower())
    if not words:
        return 0
    emphasis = {"wow","what","no","yes","insane","crazy","unbelievable","amazing","finally","never","again","bro","wait","look","oh","god","win","won","clutch","kill","headshot","legendary","secret","mistake","truth","actually","important"}
    hits = sum(1 for w in words if w in emphasis)
    density = len(words) / max(duration, 1)
    punctuation = min(3, text.count("!") + text.count("?"))
    return (hits * 2.2) + (punctuation * 0.8) + min(density, 4) + min(len(words)/25, 2)

def make_windows(rows, total, count, min_s, max_s):
    # Build candidate windows from speech, then rank them. Windows are clamped to source duration.
    candidates = []
    for row in rows:
        center = (row["start"] + row["end"]) / 2
        length = max(min_s, min(max_s, 38))
        start = max(0, center - length/2)
        end = min(total, start + length)
        start = max(0, end - length)
        text = " ".join(r["text"] for r in rows if r["start"] < end and r["end"] > start)
        score = score_segment(text, end-start)
        if end-start >= min(8, min_s):
            candidates.append({"start": start, "end": end, "text": text, "score": score})
    if not candidates:
        length = min(total, max_s)
        candidates = [{"start": 0, "end": length, "text": "", "score": 0}]
    candidates.sort(key=lambda x: x["score"], reverse=True)
    chosen = []
    for c in candidates:
        if all(c["end"] <= x["start"] or c["start"] >= x["end"] for x in chosen):
            chosen.append(c)
        if len(chosen) >= count:
            break
    if len(chosen) < count:
        # Fill remaining slots with evenly distributed windows, avoiding duplicates.
        length = min(total, max_s)
        for i in range(count * 3):
            start = max(0, min(total-length, (total-length) * (i+1)/(count*3+1)))
            end = start + length
            if all(end <= x["start"] or start >= x["end"] for x in chosen):
                chosen.append({"start": start, "end": end, "text": "", "score": 0})
            if len(chosen) >= count:
                break
    return sorted(chosen[:count], key=lambda x: x["start"])

def subtitle_filter(rows, start, end, width=1080, height=1920):
    # Create an SRT file for the selected clip; FFmpeg burns it in.
    lines, idx = [], 1
    for r in rows:
        a, b = max(start, r["start"]), min(end, r["end"])
        if b <= a:
            continue
        def stamp(t):
            ms = int(round(t*1000))
            h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
            return f"{h:02}:{m:02}:{s:02},{ms:03}"
        text = r["text"].replace("-->", "→").replace("\n", " ")
        lines += [str(idx), f"{stamp(a-start)} --> {stamp(b-start)}", text, ""]
        idx += 1
    return "\n".join(lines)

def create_clip(source, out, start, end, rows, index):
    duration = max(1, end-start)
    srt = out.with_suffix(".srt")
    srt.write_text(subtitle_filter(rows, start, end), encoding="utf-8")
    # Center crop to vertical 9:16, then scale. Works for landscape and portrait sources.
    # subtitles are optional if no speech was detected.
    if rows:
        srt_path = str(srt).replace("\\", "/").replace(":", r"\:")
        vf = f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,subtitles='{srt_path}':force_style='FontName=Arial,FontSize=16,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Shadow=1,Alignment=2,MarginV=150'"
    else:
        vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"
    run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(duration), "-vf", vf,
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k",
         "-movflags", "+faststart", str(out)], timeout=60*60)
    try: srt.unlink()
    except: pass

def process_job(job_id, source, clip_count, min_s, max_s):
    try:
        with job_lock:
            jobs[job_id]["status"] = "transcribing"
            jobs[job_id]["progress"] = 12
            jobs[job_id]["message"] = "Transcribing audio with Whisper…"
        total = probe_duration(source)
        rows, language = transcribe(source)
        with job_lock:
            jobs[job_id]["progress"] = 48
            jobs[job_id]["message"] = "Finding candidate highlights…"
            jobs[job_id]["language"] = language
        windows = make_windows(rows, total, clip_count, min_s, max_s)
        result = []
        for i, w in enumerate(windows, 1):
            out = OUTPUTS / job_id / f"clip_{i:02}.mp4"
            out.parent.mkdir(parents=True, exist_ok=True)
            create_clip(source, out, w["start"], w["end"], rows, i)
            result.append({"id": f"{job_id}_{i}", "name": f"Clip {i}", "start": round(w["start"],1),
                           "end": round(w["end"],1), "score": round(w["score"],1),
                           "text": w["text"][:260], "url": f"/api/clips/{job_id}/clip_{i:02}.mp4"})
            with job_lock:
                jobs[job_id]["progress"] = 48 + int(48*i/max(1,len(windows)))
                jobs[job_id]["message"] = f"Rendering clip {i} of {len(windows)}…"
        with job_lock:
            jobs[job_id].update(status="completed", progress=100, message="Your clips are ready.", clips=result,
                                language=language, duration=round(total,1))
    except Exception as e:
        with job_lock:
            jobs[job_id].update(status="failed", progress=0, message=str(e)[-1200:])

def start_job(source, clip_count, min_s, max_s, original_name):
    job_id = uuid.uuid4().hex[:12]
    with job_lock:
        jobs[job_id] = {"id": job_id, "status": "queued", "progress": 2, "message": "Queued for processing…",
                        "clips": [], "filename": original_name, "created": time.time()}
    thread = threading.Thread(target=process_job, args=(job_id, source, clip_count, min_s, max_s), daemon=True)
    thread.start()
    return job_id

@app.get("/")
def home():
    return FileResponse(BASE / "app" / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "ClipForge AI"}

@app.post("/api/upload")
async def upload_video(file: UploadFile = File(...), clip_count: int = Form(5), min_seconds: int = Form(20), max_seconds: int = Form(60)):
    allowed = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
    ext = Path(file.filename or "").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, "Unsupported video type. Upload MP4, MOV, MKV, WebM, AVI, or M4V.")
    max_bytes = int(os.getenv("MAX_UPLOAD_MB", "2048")) * 1024 * 1024
    path = UPLOADS / f"{uuid.uuid4().hex}{ext}"
    size = 0
    try:
        with path.open("wb") as f:
            while chunk := await file.read(1024*1024):
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(413, "Video exceeds the configured upload limit.")
                f.write(chunk)
    except:
        path.unlink(missing_ok=True)
        raise
    jid = start_job(path, max(1,min(10,clip_count)), max(8,min(120,min_seconds)), max(10,min(180,max_seconds)), file.filename)
    return {"job_id": jid}

@app.post("/api/youtube")
def youtube(req: UrlRequest):
    if not req.url.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")):
        raise HTTPException(400, "Please provide a valid HTTPS YouTube URL.")
    job_id = uuid.uuid4().hex[:12]
    with job_lock:
        jobs[job_id] = {"id": job_id, "status": "downloading", "progress": 3, "message": "Downloading authorized source…", "clips": [], "filename": "YouTube video"}
    def download_and_process():
        try:
            target = UPLOADS / f"{job_id}.%(ext)s"
            run(["yt-dlp", "--no-playlist", "-f", "bv*[height<=1080]+ba/b[height<=1080]/b", "--merge-output-format", "mp4",
                 "-o", str(target), req.url], timeout=60*60)
            candidates = list(UPLOADS.glob(job_id + ".*"))
            candidates = [p for p in candidates if p.suffix.lower() in {".mp4",".mkv",".webm",".mov"}]
            if not candidates: raise RuntimeError("Download completed but no supported video file was found.")
            with job_lock:
                jobs[job_id]["status"] = "queued"
                jobs[job_id]["progress"] = 8
                jobs[job_id]["message"] = "Download complete. Starting AI analysis…"
            process_job(job_id, candidates[0], max(1,min(10,req.clip_count)), max(8,min(120,req.min_seconds)), max(10,min(180,req.max_seconds)))
        except Exception as e:
            with job_lock: jobs[job_id].update(status="failed", progress=0, message=str(e)[-1200:])
    threading.Thread(target=download_and_process, daemon=True).start()
    return {"job_id": job_id}

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    with job_lock:
        job = jobs.get(job_id)
        if not job: raise HTTPException(404, "Job not found (server may have restarted).")
        return dict(job)

@app.get("/api/clips/{job_id}/{filename}")
def get_clip(job_id: str, filename: str):
    if not re.fullmatch(r"clip_\d{2}\.mp4", filename):
        raise HTTPException(400, "Invalid clip filename.")
    path = OUTPUTS / job_id / filename
    if not path.exists(): raise HTTPException(404, "Clip not found.")
    return FileResponse(path, media_type="video/mp4", filename=filename)

@app.get("/api/jobs/{job_id}/download")
def download_all(job_id: str):
    folder = OUTPUTS / job_id
    if not folder.exists(): raise HTTPException(404, "No clips found.")
    import zipfile
    archive = OUTPUTS / f"{job_id}_clips.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.glob("clip_*.mp4")): z.write(p, p.name)
    return FileResponse(archive, media_type="application/zip", filename="clipforge-clips.zip")
