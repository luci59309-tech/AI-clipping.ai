# ClipForge AI — Online deployment

## Architecture
- Frontend: Netlify (static HTML/CSS/JS)
- Python API + Whisper + FFmpeg: Render Docker web service
- Video files and generated clips: persistent backend disk

Netlify does not run this Python/FFmpeg worker as a static website. The backend is
included in this package and must be deployed as a separate service.

## 1. Deploy the Python backend to Render
1. Upload this whole project to a GitHub repository.
2. In Render, choose **New + → Blueprint** and connect the repository.
3. Render reads `render.yaml` and creates the Docker API service.
4. The blueprint uses a Starter service and a 10 GB persistent disk. These are
   paid resources; check Render's current pricing before deploying.
5. Wait for the service to build. Test `https://YOUR-API.onrender.com/api/health`.
   It should return JSON containing `"ok": true`.

## 2. Connect Netlify frontend
1. Deploy the `netlify-frontend` folder to Netlify (or connect the repository and
   set the publish directory to `netlify-frontend`).
2. Edit `netlify-frontend/config.js`:
   `window.CLIPFORGE_API_URL = "https://YOUR-API.onrender.com";`
3. Redeploy the Netlify site.
4. For tighter security, change the backend's `CORS_ORIGINS` environment variable
   in Render to your exact Netlify site URL, e.g. `https://your-site.netlify.app`.

## 3. Local testing
From the project root:
`docker compose up --build`
Then visit `http://localhost:8000`. The backend serves the original bundled UI at
that address; for the Netlify frontend, set config.js to `http://localhost:8000`.

## Important
- First boot downloads the Whisper model. This can take several minutes.
- CPU transcription can be slow. This app is not yet optimized for high traffic.
- A persistent disk and adequate RAM/CPU are needed for reliable video processing.
- The app has no user login, quotas, or abuse protection yet. Do not expose it publicly
  as a multi-user service without adding authentication, rate limits, and upload controls.
- YouTube URL processing relies on yt-dlp; platform changes may temporarily break it.
- Only process videos you own or are authorized to use.
- AI highlight selection in this version is transcript-based heuristic scoring, not
  full semantic/game-event understanding.
