# ClipForge AI

A self-hosted, free-to-run AI-assisted auto-clipping web app for gaming, podcasts, interviews, and general videos.

## What it does
- Upload MP4/MOV/MKV/WebM videos or provide a YouTube URL for videos you own or are authorized to download.
- Transcribes speech with faster-whisper (CPU mode by default).
- Scores transcript segments for likely highlights using speech density, emphasis words, and punctuation.
- Creates vertical 9:16 clips with FFmpeg, burns in readable subtitles, and provides MP4 downloads.
- Includes a browser dashboard and job progress polling.

This is a working starter application, not a hosted SaaS. You run it on your own computer/server. AI highlight ranking is heuristic in this first version; it does not claim to understand every visual joke, game kill, or context.

## Quick start (Docker)
Requirements: Docker Desktop (Windows/macOS) or Docker Engine + Compose (Linux).

```bash
docker compose up --build
```
Open http://localhost:8000

First run downloads the Whisper model (`base`) and may take several minutes. CPU transcription can be slow for long videos. Change `WHISPER_MODEL` in `docker-compose.yml` to `tiny` for faster, less accurate transcription or `small` for better accuracy.

## Run without Docker
Install FFmpeg and Python 3.11+, then:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000

## YouTube URL notes
The app uses `yt-dlp`. Only download videos you own, have permission to use, or are otherwise legally entitled to download. Some URLs may be unavailable due to platform restrictions, age/region limits, or authentication requirements. YouTube may change its delivery methods and break downloads.

## Important limitations / safety
- No account system or cloud hosting is included. Keep the server private if you expose it to a network.
- No guarantee every generated clip is a viral highlight. Review clips before publishing.
- Subtitles are burned into the video; they are not yet editable word-by-word.
- The first version uses a fixed vertical crop. Advanced face/speaker tracking and game-event detection are future upgrades.
- Do not upload private, copyrighted, or sensitive videos unless you have the necessary rights and consent.


## Online deployment
See [DEPLOY-ONLINE.md](DEPLOY-ONLINE.md). The Netlify frontend is in `netlify-frontend/`; the Python API, Dockerfile, and Render blueprint are included in the project root.
